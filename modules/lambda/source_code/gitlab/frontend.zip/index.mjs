import { execSync } from 'child_process'
import { tmpdir } from 'os';
import { join } from 'path';
import { writeFileSync, unlinkSync } from 'fs';

export const handler = async (event, context) => {
    const time = Date.now()
    const lambdaDataFilePath = join(tmpdir(), `lambda_data_${time}.txt`);
    const data = JSON.stringify({
        headers: event.headers,
        context: context,
        payload: event.body
    });
    writeFileSync(lambdaDataFilePath, data);
    const res = execSync(`./spectral_bot-cli --environment production task gitlab_aws_frontend lambda_data_file_path:'${lambdaDataFilePath}'`, { stdio: 'inherit' })
    const response = {
        statusCode: 202,
        body: res,
    };
    return response;
};