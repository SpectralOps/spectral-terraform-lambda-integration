import { execSync } from 'child_process'

export const handler = async (event) => {
    const payload = JSON.stringify(event)
    const res = execSync(`./spectral_bot-cli --environment production task gitlab_aws_backend payload:"$(cat <<'EOF'
${payload}
EOF
)"`, { stdio: 'inherit' })

    const response = {
        statusCode: 202,
        body: res,
    };
    return response;
};